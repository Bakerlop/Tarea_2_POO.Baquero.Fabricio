package com.mycompany.vehiculosbaquero;
public class VehiculosBaquero {
   public static void main(String[] args){
        CarroBaquero codigo=new CarroBaquero("Negro",120,4,4);
        System.out.println(" Color del carro " + codigo.devuelveColor()+ " La velocidad moderada es " + codigo.devuelveVelocidad() + " Numero de pasajeros " + codigo.devuelvePasajeros());
        System.out.println(codigo.velocidad);
        
        MotoBaquero obj=new MotoBaquero("Honda","Japones",10,"Deportiva");
        System.out.println(" Marca del moto " + obj.devuelveMarca() + " Origen es " + obj.devuelveOrigen() + " Tipo de moto es " + obj.devuelveTipo());        
        }
}

