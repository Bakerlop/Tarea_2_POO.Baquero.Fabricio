package com.mycompany.ejbaquero;

public class EjBaquero {
  public static void main(String[] args) {
        PersonaBaquero ob=new PersonaBaquero("Fabricio","Baquero",30,1719271643);
        ob.setId(1719271643);
        
        System.out.println(" Mi nombre es " + ob.nombre + " Mi apellido es " + ob.apellido + " Mi edad es " + ob.edad + " Mi número de cédula es " + ob.getId());
   
    }
}

  
