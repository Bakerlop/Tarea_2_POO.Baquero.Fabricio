
package com.mycompany.ejbaquero;

public class PersonaBaquero {
    public String nombre;
    public String apellido;
    public int edad;
    public int id;

    public PersonaBaquero() {
    }

    public PersonaBaquero(String nombre, String apellido, int edad, int id) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.id = id;
    }

    public int getId() {
        return id;
    }
    public void setId(int id){
        this.id=id;
    }
}