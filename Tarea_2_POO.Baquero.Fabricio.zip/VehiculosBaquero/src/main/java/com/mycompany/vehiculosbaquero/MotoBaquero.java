package com.mycompany.vehiculosbaquero;
public class MotoBaquero {
    String marca;
    String origen;
    int edad;
    String tipo;
    public MotoBaquero(String marca, String origen, int edad, String tipo){
       this.marca=marca;
       this.origen=origen;
       this.edad=edad;
       this.tipo=tipo;
           
    }
    public String devuelveMarca (){
        return marca;
    }
    public String devuelveOrigen (){
        return origen;
    }
    private int devuelveEdad (){
        return edad;
    }
    public String devuelveTipo (){
        return tipo;
    }
    public void arranca(){
        System.out.println("Arranca esta moto");
    }
}