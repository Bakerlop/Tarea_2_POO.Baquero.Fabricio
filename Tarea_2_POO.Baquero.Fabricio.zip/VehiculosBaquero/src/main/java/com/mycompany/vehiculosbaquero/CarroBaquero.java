
package com.mycompany.vehiculosbaquero;
public class CarroBaquero {
    String color;
    double velocidad;
    int ruedas;
    int pasajeros;
    public CarroBaquero(String color, double velocidad, int ruedas, int pasajeros){
        this.color=color;
        this.velocidad=velocidad;
        this.ruedas=ruedas;
        this.pasajeros=pasajeros;
    }
    public String devuelveColor (){
        return color;
    }
    public double devuelveVelocidad (){
        return velocidad;
    }
    private int devuelveRuedas (){
        return ruedas;
    }
    public int devuelvePasajeros (){
        return pasajeros;
    }
    public void arranca(){
        System.out.println("Arranca este carro");
    }
    public void frena(){
        System.out.println("Frena este carro");
    }
}